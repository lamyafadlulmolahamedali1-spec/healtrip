"""
╔══════════════════════════════════════════════════════════════════════╗
║   PEPPER CLINICAL INFINITY V6 — Clinical Module                     ║
║   © 2026 Lamya F. H. Ali — All Rights Reserved                       ║
║   ISAA assessment (Indian Scale for Assessment of Autism) +          ║
║   AI Clinical Advisor with full per-question memory map.             ║
╚══════════════════════════════════════════════════════════════════════╝
"""

# ──────────────────────────────────────────────────────────────────────
#  ISAA — Indian Scale for Assessment of Autism
#  6 domains, 40 items. Each item scored 1-5:
#    1 = Rarely (up to 20%)   2 = Sometimes (21-40%)
#    3 = Frequently (41-60%)  4 = Mostly (61-80%)  5 = Always (81-100%)
#  Total score interpretation:
#    < 70  = No autism
#    70-106 = Mild autism
#    107-153 = Moderate autism
#    > 153 = Severe autism
# ──────────────────────────────────────────────────────────────────────
ISAA_DOMAINS = {
    "Social Relationship & Reciprocity": [
        "Has poor eye contact",
        "Lacks social smile",
        "Remains aloof / prefers to be alone",
        "Does not reach out to others",
        "Unable to relate to people",
        "Unable to respond to social/environmental cues",
        "Engages in solitary and repetitive play",
        "Unable to take turns in social interaction",
        "Does not maintain peer relationships",
    ],
    "Emotional Responsiveness": [
        "Shows inappropriate emotional response",
        "Shows exaggerated emotions",
        "Engages in self-stimulating emotions",
        "Lacks fear of danger",
        "Excited or agitated for no apparent reason",
    ],
    "Speech, Language & Communication": [
        "Acquired speech and lost it",
        "Has difficulty in using non-verbal language / gestures",
        "Engages in stereotyped and repetitive use of language",
        "Engages in echolalic speech (repeats words)",
        "Produces infantile squeals / unusual noises",
        "Unable to initiate or sustain conversation",
        "Uses jargon or meaningless words",
        "Uses pronoun reversals (I / you confusion)",
        "Unable to grasp pragmatics of communication",
    ],
    "Behaviour Patterns": [
        "Engages in stereotyped repetitive motor mannerisms",
        "Shows attachment to inanimate objects",
        "Shows hyperactivity / restlessness",
        "Exhibits aggressive behaviour",
        "Throws temper tantrums",
        "Engages in self-injurious behaviour",
        "Insists on sameness / resists change",
    ],
    "Sensory Aspects": [
        "Unusually sensitive to sensory stimuli",
        "Stares into space for long periods",
        "Has difficulty in tracking objects",
        "Has unusual vision",
        "Insensitive to pain",
        "Responds to objects/people unusually by smelling/touching/tasting",
    ],
    "Cognitive Component": [
        "Inconsistent attention and concentration",
        "Shows delay in responding",
        "Has unusual memory of some kind",
        "Has savant ability (exceptional skill in one area)",
    ],
}


class ISAAAssessment:
    @staticmethod
    def all_items():
        items = []
        for domain, qs in ISAA_DOMAINS.items():
            for q in qs:
                items.append({"domain": domain, "question": q})
        return items

    @staticmethod
    def total_items():
        return sum(len(v) for v in ISAA_DOMAINS.values())

    @staticmethod
    def score(answers):
        """answers: dict {index: 1..5}. Returns interpretation."""
        vals = [v for v in answers.values() if isinstance(v, (int, float))]
        total = sum(vals)
        n = len(vals)
        if total < 70:
            level = "No Autism"
            color = "#059669"
        elif total <= 106:
            level = "Mild Autism"
            color = "#0d9488"
        elif total <= 153:
            level = "Moderate Autism"
            color = "#d97706"
        else:
            level = "Severe Autism"
            color = "#dc2626"
        # Domain breakdown
        domain_scores = {}
        items = ISAAAssessment.all_items()
        for idx, val in answers.items():
            try:
                dom = items[int(idx)]["domain"]
                domain_scores[dom] = domain_scores.get(dom, 0) + val
            except (IndexError, ValueError, KeyError):
                pass
        return {
            "total": total, "answered": n, "max_possible": ISAAAssessment.total_items() * 5,
            "level": level, "color": color, "domain_scores": domain_scores,
            "interpretation": (
                f"Total ISAA score: {total}. Classification: {level}. "
                "This is a screening aid only — a qualified clinician must confirm any diagnosis."
            ),
        }


# ──────────────────────────────────────────────────────────────────────
#  AI Clinical Advisor — "Dr. Pepper"
#  Keeps a persistent memory map of every question asked + context,
#  and answers from a clinical knowledge base with topic matching.
# ──────────────────────────────────────────────────────────────────────
class ClinicalAdvisor:
    KB = {
        "meltdown": (
            "Meltdowns are involuntary responses to overload, not misbehaviour. "
            "Stay calm, reduce sensory input (lower lights/noise), give space and time, "
            "use few words, and offer a known calming item. Afterward, reconnect gently. "
            "Track triggers in the diary so patterns become visible."
        ),
        "eye contact": (
            "Forcing eye contact can increase anxiety. Build it naturally: hold a preferred toy "
            "near your face, reward any glance, and pair looking with positive outcomes. "
            "Joint attention (looking at the same object together) matters more than direct eye gaze."
        ),
        "speech": (
            "Support communication with: modeling single words, using visuals/PECS, "
            "narrating daily routines, pausing to invite responses, and honoring all communication "
            "attempts (gestures, sounds). Consult a speech-language pathologist for a tailored plan."
        ),
        "stimming": (
            "Stimming (hand-flapping, rocking) is self-regulation. Allow safe stims. "
            "Only redirect if harmful, replacing with a safe alternative that meets the same need "
            "(e.g., a chewy for mouthing). Don't punish stimming — it helps the child cope."
        ),
        "routine": (
            "Predictable routines reduce anxiety. Use a visual schedule with pictures, "
            "preview changes in advance, use timers for transitions, and keep a consistent order. "
            "TEACCH structured teaching is ideal for this."
        ),
        "sensory": (
            "Identify whether the child is over- or under-sensitive per sense. "
            "Offer a sensory diet: movement breaks, deep pressure, fidgets, noise-cancelling "
            "headphones, or dim lighting. An occupational therapist can build a profile."
        ),
        "potty": (
            "Toilet training: ensure readiness, use a visual sequence, schedule regular sits, "
            "reward success immediately, and stay consistent. Expect a longer timeline and "
            "avoid pressure; accidents are part of learning."
        ),
        "sleep": (
            "Sleep issues are common. Keep a fixed bedtime routine, reduce screens before bed, "
            "use blackout curtains and weighted blankets if soothing, and consider melatonin only "
            "under medical advice."
        ),
        "food": (
            "Food selectivity is common. Avoid pressure. Introduce new foods next to preferred ones, "
            "use repeated neutral exposure, involve the child in prep, and keep mealtimes calm. "
            "Rule out sensory or GI causes with a professional."
        ),
        "aba": (
            "ABA (Applied Behavior Analysis) breaks skills into small steps, uses reinforcement, "
            "and collects data. Modern ABA is play-based and child-led. Pepper's tasks are built on "
            "ABA, DTT, ESDM, PRT, TEACCH and Verbal Behavior principles."
        ),
        "aggression": (
            "Aggression usually communicates an unmet need or overload. Identify the function "
            "(escape, attention, sensory, tangible). Teach a replacement skill (e.g., 'break' card), "
            "keep everyone safe, and stay neutral. Track antecedents in the diary."
        ),
        "social": (
            "Build social skills with structured play, turn-taking games, social stories, "
            "and peer modeling. Start 1:1, then small groups. Reinforce every attempt at interaction."
        ),
    }

    GREETING = (
        "Hello, I'm Dr. Pepper, your clinical advisor. Ask me about meltdowns, speech, "
        "stimming, routines, sensory needs, sleep, food, toileting, aggression, social skills, "
        "or therapy methods. I remember our whole conversation."
    )

    def __init__(self):
        # Full memory map: list of {q, a, topic, ts}
        self.memory = []

    def _match(self, q):
        ql = q.lower()
        # direct keyword scan
        for key, ans in self.KB.items():
            if key in ql:
                return key, ans
        # synonym mapping
        syn = {
            "tantrum": "meltdown", "scream": "meltdown", "cry": "meltdown",
            "talk": "speech", "language": "speech", "word": "speech", "nonverbal": "speech",
            "flap": "stimming", "rock": "stimming", "repetitive": "stimming",
            "schedule": "routine", "transition": "routine", "change": "routine",
            "loud": "sensory", "noise": "sensory", "light": "sensory", "touch": "sensory",
            "toilet": "potty", "diaper": "potty",
            "bed": "sleep", "night": "sleep", "wake": "sleep",
            "eat": "food", "picky": "food", "meal": "food",
            "hit": "aggression", "bite": "aggression", "angry": "aggression",
            "friend": "social", "play": "social", "peer": "social",
            "therapy": "aba", "method": "aba", "reinforce": "aba",
            "look": "eye contact", "gaze": "eye contact",
        }
        for s, key in syn.items():
            if s in ql:
                return key, self.KB[key]
        return None, None

    def ask(self, q):
        import time
        q = (q or "").strip()
        if not q:
            return self.GREETING
        topic, ans = self._match(q)
        if ans:
            # personalize using memory of recurring topics
            recur = sum(1 for m in self.memory if m["topic"] == topic)
            prefix = ""
            if recur >= 1:
                prefix = f"(We've discussed {topic} before — building on that:) "
            reply = prefix + ans
        else:
            topic = "general"
            reply = (
                "I want to help with that. I can give clinical guidance on: meltdowns, "
                "eye contact, speech, stimming, routines, sensory needs, sleep, food, "
                "toileting, aggression, social skills, and therapy methods. "
                "Which is closest to your question?"
            )
        self.memory.append({"q": q, "a": reply, "topic": topic, "ts": time.time()})
        return reply

    def history(self):
        return self.memory

    def topics_discussed(self):
        from collections import Counter
        return dict(Counter(m["topic"] for m in self.memory))


if __name__ == "__main__":
    print("ISAA items:", ISAAAssessment.total_items())
    adv = ClinicalAdvisor()
    for q in ["my child has meltdowns", "how to improve speech?", "meltdown again", "what is ABA"]:
        print(f"\nQ: {q}\nA: {adv.ask(q)[:80]}...")
    print("\nMemory size:", len(adv.history()))
    print("Topics:", adv.topics_discussed())
