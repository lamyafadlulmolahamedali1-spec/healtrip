"""
Pepper Clinical V6 — Custom widgets: CameraThread, DrawingBoard, Celebration.
© 2026 Lamya F. H. Ali — All Rights Reserved.
"""
import time
import math
from PyQt6.QtWidgets import QWidget, QLabel
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QTimer, QPointF, QRectF, QRect
from PyQt6.QtGui import (QImage, QPixmap, QPainter, QPen, QBrush, QColor,
                          QPainterPath, QFont, QPolygonF)

try:
    import cv2
    from vision_engine import VisionEngine
    _HAS_VISION = True
except Exception:
    _HAS_VISION = False


# ════════════════════════════════════════════════════════════════════
#  Camera worker thread — high performance, fire-and-forget rendering
# ════════════════════════════════════════════════════════════════════
class CameraThread(QThread):
    frame_ready = pyqtSignal(QImage)
    results_ready = pyqtSignal(dict)
    error = pyqtSignal(str)

    def __init__(self, cam_index=0):
        super().__init__()
        self._run = False
        self.cam_index = cam_index
        self.engine = VisionEngine() if _HAS_VISION else None
        self._draw = True

    def run(self):
        if not _HAS_VISION:
            self.error.emit("Camera/vision not available on this system.")
            return
        cap = cv2.VideoCapture(self.cam_index)
        if not cap.isOpened():
            self.error.emit("Could not open camera. Check permissions / device.")
            return
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        cap.set(cv2.CAP_PROP_FPS, 30)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        self._run = True
        while self._run:
            ok, frame = cap.read()
            if not ok:
                continue
            frame = cv2.flip(frame, 1)  # mirror
            try:
                annotated, res = self.engine.process(frame, draw=self._draw)
            except Exception:
                annotated, res = frame, {}
            rgb = cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb.shape
            img = QImage(rgb.data, w, h, ch * w, QImage.Format.Format_RGB888).copy()
            self.frame_ready.emit(img)
            if res:
                self.results_ready.emit(res)
            self.msleep(15)  # ~ up to 60 fps cap
        cap.release()
        if self.engine:
            self.engine.close()

    def stop(self):
        self._run = False
        self.wait(1500)


# ════════════════════════════════════════════════════════════════════
#  Drawing board — child traces over a light guide; we detect coverage
# ════════════════════════════════════════════════════════════════════
class DrawingBoard(QWidget):
    completed = pyqtSignal(bool)  # True if traced well enough

    def __init__(self):
        super().__init__()
        self.setMinimumSize(420, 420)
        self.setStyleSheet("background:white; border-radius:14px;")
        self._strokes = []          # list of list[QPointF]
        self._cur = None
        self.guide_points = []      # sampled points of the guide path
        self.guide_path = QPainterPath()
        self.target_label = ""
        self._covered = set()
        self.pen_color = QColor("#7c3aed")

    def set_target(self, kind, target):
        """Build a light guide path for letter / shape / element."""
        self._strokes = []
        self._covered = set()
        self.target_label = str(target)
        w, h = self.width() or 420, self.height() or 420
        self.guide_path = self._make_path(kind, target, w, h)
        self.guide_points = self._sample(self.guide_path, 160)
        self.update()

    def _make_path(self, kind, target, w, h):
        p = QPainterPath()
        cx, cy = w / 2, h / 2
        s = min(w, h) * 0.34
        if kind == "shape" or kind == "element":
            t = str(target).lower()
            if t in ("circle", "oval"):
                p.addEllipse(QPointF(cx, cy), s, s if t == "circle" else s * 0.7)
            elif t in ("square", "rectangle"):
                p.addRect(QRectF(cx - s, cy - s, 2 * s, 2 * s))
            elif t == "triangle":
                poly = QPolygonF([QPointF(cx, cy - s), QPointF(cx - s, cy + s), QPointF(cx + s, cy + s), QPointF(cx, cy - s)])
                p.addPolygon(poly)
            elif t == "heart":
                p.moveTo(cx, cy + s * 0.6)
                p.cubicTo(cx + s * 1.4, cy - s * 0.4, cx + s * 0.4, cy - s, cx, cy - s * 0.3)
                p.cubicTo(cx - s * 0.4, cy - s, cx - s * 1.4, cy - s * 0.4, cx, cy + s * 0.6)
            elif t == "star":
                pts = []
                for i in range(10):
                    ang = math.pi / 2 + i * math.pi / 5
                    r = s if i % 2 == 0 else s * 0.45
                    pts.append(QPointF(cx + r * math.cos(ang), cy - r * math.sin(ang)))
                p.addPolygon(QPolygonF(pts + [pts[0]]))
            elif t == "line":
                p.moveTo(cx - s, cy); p.lineTo(cx + s, cy)
            elif t == "cross":
                p.moveTo(cx, cy - s); p.lineTo(cx, cy + s)
                p.moveTo(cx - s, cy); p.lineTo(cx + s, cy)
            elif t == "zigzag":
                p.moveTo(cx - s, cy - s)
                p.lineTo(cx - s / 3, cy + s); p.lineTo(cx + s / 3, cy - s); p.lineTo(cx + s, cy + s)
            else:
                p.addEllipse(QPointF(cx, cy), s, s)
        else:
            # letter / word — draw text outline as guide
            font = QFont("Arial", int(s * 1.6))
            font.setBold(True)
            p.addText(QPointF(cx - s * 0.6 * len(str(target)), cy + s * 0.6), font, str(target))
        return p

    def _sample(self, path, n):
        pts = []
        length = path.length()
        if length == 0:
            return pts
        for i in range(n + 1):
            pct = i / n
            pt = path.pointAtPercent(pct)
            pts.append((pt.x(), pt.y()))
        return pts

    def mousePressEvent(self, e):
        self._cur = [QPointF(e.position())]
        self._strokes.append(self._cur)
        self._mark(e.position())
        self.update()

    def mouseMoveEvent(self, e):
        if self._cur is not None:
            self._cur.append(QPointF(e.position()))
            self._mark(e.position())
            self.update()

    def mouseReleaseEvent(self, e):
        self._cur = None
        self._check()

    def _mark(self, pos):
        # mark nearby guide points as covered
        for i, (gx, gy) in enumerate(self.guide_points):
            if abs(gx - pos.x()) < 26 and abs(gy - pos.y()) < 26:
                self._covered.add(i)

    def coverage(self):
        if not self.guide_points:
            return 0.0
        return len(self._covered) / len(self.guide_points)

    def _check(self):
        cov = self.coverage()
        if cov >= 0.55:
            self.completed.emit(True)

    def clear(self):
        self._strokes = []
        self._covered = set()
        self.update()

    def paintEvent(self, e):
        qp = QPainter(self)
        qp.setRenderHint(QPainter.RenderHint.Antialiasing)
        qp.fillRect(self.rect(), QColor("white"))
        # light guide
        pen = QPen(QColor(167, 139, 250, 120), 16, Qt.PenStyle.SolidLine,
                   Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        qp.setPen(pen)
        qp.drawPath(self.guide_path)
        # child strokes
        pen2 = QPen(self.pen_color, 8, Qt.PenStyle.SolidLine,
                    Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        qp.setPen(pen2)
        for stroke in self._strokes:
            for i in range(1, len(stroke)):
                qp.drawLine(stroke[i - 1], stroke[i])
        # coverage label
        qp.setPen(QColor("#6d28d9"))
        qp.setFont(QFont("Arial", 11, QFont.Weight.Bold))
        qp.drawText(10, 22, f"Trace: {int(self.coverage()*100)}%")


# ════════════════════════════════════════════════════════════════════
#  Celebration overlay — stars + crown 👑, shown every 10 tasks
# ════════════════════════════════════════════════════════════════════
class Celebration(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.hide()
        self._stars = []
        self._t = QTimer(self)
        self._t.timeout.connect(self._tick)
        self._frames = 0

    def celebrate(self):
        import random
        self._stars = []
        w = self.width() or 800
        for _ in range(40):
            self._stars.append({
                "x": random.uniform(0, w), "y": random.uniform(-200, 0),
                "vy": random.uniform(3, 9), "sz": random.uniform(14, 34),
                "rot": random.uniform(0, 360),
                "color": random.choice(["#fbbf24", "#f472b6", "#a78bfa", "#34d399", "#60a5fa"]),
            })
        self._frames = 0
        self.raise_()
        self.show()
        self._t.start(30)

    def _tick(self):
        self._frames += 1
        h = self.height() or 600
        for s in self._stars:
            s["y"] += s["vy"]
            s["rot"] += 6
        self.update()
        if self._frames > 90:
            self._t.stop()
            self.hide()

    def paintEvent(self, e):
        if not self.isVisible():
            return
        qp = QPainter(self)
        qp.setRenderHint(QPainter.RenderHint.Antialiasing)
        # dim
        qp.fillRect(self.rect(), QColor(45, 27, 105, 60))
        w = self.width()
        # crown + text
        qp.setFont(QFont("Arial", 64))
        qp.drawText(self.rect().adjusted(0, -40, 0, -40),
                    Qt.AlignmentFlag.AlignCenter, "👑")
        qp.setFont(QFont("Arial", 26, QFont.Weight.Bold))
        qp.setPen(QColor("white"))
        qp.drawText(self.rect().adjusted(0, 60, 0, 60),
                    Qt.AlignmentFlag.AlignCenter, "You are a STAR! 🎉")
        # falling stars
        for s in self._stars:
            qp.save()
            qp.translate(s["x"], s["y"])
            qp.rotate(s["rot"])
            qp.setBrush(QBrush(QColor(s["color"])))
            qp.setPen(Qt.PenStyle.NoPen)
            self._draw_star(qp, s["sz"])
            qp.restore()

    def _draw_star(self, qp, size):
        path = QPainterPath()
        for i in range(10):
            ang = math.pi / 2 + i * math.pi / 5
            r = size if i % 2 == 0 else size * 0.45
            x = r * math.cos(ang)
            y = -r * math.sin(ang)
            if i == 0:
                path.moveTo(x, y)
            else:
                path.lineTo(x, y)
        path.closeSubpath()
        qp.drawPath(path)


if __name__ == "__main__":
    print("widgets module OK. Vision:", _HAS_VISION)
