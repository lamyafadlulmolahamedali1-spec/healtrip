"""
╔══════════════════════════════════════════════════════════════════════╗
║   PEPPER CLINICAL INFINITY V6 — AI Vision Engine                     ║
║   © 2026 Lamya F. H. Ali — All Rights Reserved                       ║
║   High-performance MediaPipe: skeleton · joints · posture ·          ║
║   emotion · finger counting. NO feet/jumping tasks.                  ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import math
import time
import numpy as np

try:
    import cv2
    _HAS_CV = True
except Exception:
    _HAS_CV = False

# MediaPipe solutions API (standard on `pip install mediapipe`).
# Some minimal builds ship only the Tasks API; we detect that and
# fall back to OpenCV Haar cascades so the app still runs everywhere.
_HAS_MP = False
try:
    import mediapipe as mp
    _ = mp.solutions.pose  # probe — raises on stripped builds
    _HAS_MP = True
except Exception:
    _HAS_MP = False


# ──────────────────────────────────────────────────────────────────────
#  Geometry helpers
# ──────────────────────────────────────────────────────────────────────
def _angle(a, b, c):
    """Angle at point b (degrees) given three (x,y) points."""
    ba = (a[0] - b[0], a[1] - b[1])
    bc = (c[0] - b[0], c[1] - b[1])
    dot = ba[0] * bc[0] + ba[1] * bc[1]
    na = math.hypot(*ba)
    nc = math.hypot(*bc)
    if na * nc == 0:
        return 0.0
    cosv = max(-1.0, min(1.0, dot / (na * nc)))
    return math.degrees(math.acos(cosv))


def _dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


# ──────────────────────────────────────────────────────────────────────
#  AI Vision Engine
# ──────────────────────────────────────────────────────────────────────
class VisionEngine:
    """
    Wraps MediaPipe Holistic-style detection using separate, fast solutions:
      - Pose (skeleton + joint angles + posture)
      - Hands (finger counting + gestures)
      - FaceMesh (emotion estimate + attention)
    Tuned for high FPS: low model complexity, frame downscale, lazy init.
    """

    def __init__(self, max_hands=2, det_conf=0.6, trk_conf=0.5):
        self.ok = _HAS_CV
        self.use_mp = _HAS_MP
        self._init = False
        self._max_hands = max_hands
        self._det = det_conf
        self._trk = trk_conf
        self.pose = None
        self.hands = None
        self.face = None
        self._mp_draw = None
        self._mp_pose = None
        self._mp_hands = None
        self._mp_face = None
        self._face_cascade = None  # OpenCV fallback
        # cached results
        self.last = {
            "fingers": 0, "fingers_left": 0, "fingers_right": 0,
            "gesture": "none", "emotion": "neutral", "attention": 0.0,
            "pose_detected": False, "hands_detected": False, "face_detected": False,
            "joints": {}, "posture": "unknown", "hand_raised": False,
            "clap": False, "head_touch": False,
        }
        self._prev_wrist = None
        self._clap_t = 0

    def _ensure(self):
        if self._init or not self.ok:
            return
        if self.use_mp:
            self._mp_pose = mp.solutions.pose
            self._mp_hands = mp.solutions.hands
            self._mp_face = mp.solutions.face_mesh
            self._mp_draw = mp.solutions.drawing_utils
            self._mp_styles = mp.solutions.drawing_styles
            # Low complexity = high FPS
            self.pose = self._mp_pose.Pose(
                model_complexity=1, smooth_landmarks=True,
                min_detection_confidence=self._det, min_tracking_confidence=self._trk)
            self.hands = self._mp_hands.Hands(
                max_num_hands=self._max_hands, model_complexity=0,
                min_detection_confidence=self._det, min_tracking_confidence=self._trk)
            self.face = self._mp_face.FaceMesh(
                max_num_faces=1, refine_landmarks=True,
                min_detection_confidence=self._det, min_tracking_confidence=self._trk)
        else:
            # OpenCV fallback: face detection only (keeps app functional)
            self._face_cascade = cv2.CascadeClassifier(
                cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
        self._init = True

    # ── Finger counting ────────────────────────────────────────────────
    def _count_fingers(self, hand_landmarks, handedness_label):
        """Return number of extended fingers (0-5) for one hand."""
        lm = hand_landmarks.landmark
        tips = [4, 8, 12, 16, 20]
        pips = [3, 6, 10, 14, 18]
        count = 0
        # Thumb: compare x (depends on hand)
        if handedness_label == "Right":
            if lm[tips[0]].x < lm[pips[0]].x:
                count += 1
        else:
            if lm[tips[0]].x > lm[pips[0]].x:
                count += 1
        # Other 4 fingers: tip above pip (smaller y = up)
        for i in range(1, 5):
            if lm[tips[i]].y < lm[pips[i]].y:
                count += 1
        return count

    def _gesture(self, total_fingers, hands_data):
        if total_fingers == 0:
            return "fist"
        if total_fingers == 10 or (len(hands_data) == 1 and total_fingers == 5):
            return "open_palm"
        # Peace = index+middle up only
        for hl, label in hands_data:
            lm = hl.landmark
            idx_up = lm[8].y < lm[6].y
            mid_up = lm[12].y < lm[10].y
            ring_up = lm[16].y < lm[14].y
            pinky_up = lm[20].y < lm[18].y
            thumb_up = (lm[4].x < lm[3].x) if label == "Right" else (lm[4].x > lm[3].x)
            if idx_up and mid_up and not ring_up and not pinky_up:
                return "peace"
            if thumb_up and not idx_up and not mid_up and not ring_up and not pinky_up:
                return "thumbs_up"
            if idx_up and not mid_up and not ring_up and not pinky_up:
                return "point"
        return "open"

    # ── Posture / joints from pose ─────────────────────────────────────
    def _analyze_pose(self, pose_lm, w, h):
        lm = pose_lm.landmark
        P = self._mp_pose.PoseLandmark

        def pt(idx):
            return (lm[idx].x * w, lm[idx].y * h)

        joints = {}
        try:
            # Elbows
            joints["left_elbow"] = round(_angle(pt(P.LEFT_SHOULDER), pt(P.LEFT_ELBOW), pt(P.LEFT_WRIST)))
            joints["right_elbow"] = round(_angle(pt(P.RIGHT_SHOULDER), pt(P.RIGHT_ELBOW), pt(P.RIGHT_WRIST)))
            # Shoulders
            joints["left_shoulder"] = round(_angle(pt(P.LEFT_ELBOW), pt(P.LEFT_SHOULDER), pt(P.LEFT_HIP)))
            joints["right_shoulder"] = round(_angle(pt(P.RIGHT_ELBOW), pt(P.RIGHT_SHOULDER), pt(P.RIGHT_HIP)))
        except Exception:
            pass

        # Posture: shoulder/hip vertical alignment
        posture = "unknown"
        try:
            ls, rs = pt(P.LEFT_SHOULDER), pt(P.RIGHT_SHOULDER)
            shoulder_tilt = abs(ls[1] - rs[1])
            posture = "upright" if shoulder_tilt < h * 0.06 else "leaning"
        except Exception:
            pass

        # Hand raised: wrist above shoulder
        hand_raised = False
        head_touch = False
        try:
            if lm[P.LEFT_WRIST].y < lm[P.LEFT_SHOULDER].y or lm[P.RIGHT_WRIST].y < lm[P.RIGHT_SHOULDER].y:
                hand_raised = True
            nose = pt(P.NOSE)
            if _dist(pt(P.LEFT_WRIST), nose) < w * 0.12 or _dist(pt(P.RIGHT_WRIST), nose) < w * 0.12:
                head_touch = True
        except Exception:
            pass

        return joints, posture, hand_raised, head_touch

    # ── Emotion estimate from face mesh ────────────────────────────────
    def _analyze_emotion(self, face_lm, w, h):
        lm = face_lm.landmark

        def pt(i):
            return (lm[i].x * w, lm[i].y * h)

        try:
            # Mouth corners 61,291 ; top/bottom lip 13,14
            mouth_w = _dist(pt(61), pt(291))
            mouth_h = _dist(pt(13), pt(14))
            # Eyebrow raise: 70 (brow) vs 159 (eye)
            brow = _dist(pt(70), pt(159)) + _dist(pt(300), pt(386))
            face_h = _dist(pt(10), pt(152)) + 1e-6
            smile_ratio = mouth_w / face_h
            open_ratio = mouth_h / face_h
            brow_ratio = brow / face_h

            if open_ratio > 0.18 and brow_ratio > 0.22:
                emo = "surprised"
            elif smile_ratio > 0.46:
                emo = "happy"
            elif smile_ratio < 0.38 and open_ratio < 0.05:
                emo = "sad"
            elif brow_ratio < 0.16:
                emo = "angry"
            else:
                emo = "neutral"

            # Attention: face roughly centered & facing forward
            cx = pt(1)[0] / w
            attention = max(0.0, 1.0 - abs(cx - 0.5) * 2) * 100
            return emo, round(attention, 1)
        except Exception:
            return "neutral", 0.0

    # ── Main per-frame processing ──────────────────────────────────────
    def process(self, frame_bgr, draw=True):
        """
        Process one BGR frame. Returns (annotated_frame, results_dict).
        High-performance: processes on RGB, optional draw overlay.
        """
        if not self.ok:
            return frame_bgr, self.last
        self._ensure()

        h, w = frame_bgr.shape[:2]

        # ── OpenCV fallback (stripped MediaPipe build) ──
        if not self.use_mp:
            gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
            faces = self._face_cascade.detectMultiScale(gray, 1.2, 5, minSize=(80, 80))
            res = dict(self.last)
            res["clap"] = False
            if len(faces) > 0:
                (fx, fy, fw, fh) = sorted(faces, key=lambda b: -b[2] * b[3])[0]
                res["face_detected"] = True
                cx = (fx + fw / 2) / w
                res["attention"] = round(max(0.0, 1.0 - abs(cx - 0.5) * 2) * 100, 1)
                res["emotion"] = "neutral"
                if draw:
                    cv2.rectangle(frame_bgr, (fx, fy), (fx + fw, fy + fh), (124, 58, 237), 2)
                    cv2.putText(frame_bgr, "Face", (fx, fy - 8),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (124, 58, 237), 2)
            else:
                res["face_detected"] = False
                res["attention"] = 0.0
            self.last = res
            return frame_bgr, res

        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        rgb.flags.writeable = False

        pose_res = self.pose.process(rgb)
        hands_res = self.hands.process(rgb)
        face_res = self.face.process(rgb)

        rgb.flags.writeable = True
        out = frame_bgr

        res = dict(self.last)
        res.update({"clap": False})

        # ── Pose ──
        if pose_res.pose_landmarks:
            res["pose_detected"] = True
            joints, posture, hand_raised, head_touch = self._analyze_pose(pose_res.pose_landmarks, w, h)
            res["joints"] = joints
            res["posture"] = posture
            res["hand_raised"] = hand_raised
            res["head_touch"] = head_touch
            if draw:
                self._mp_draw.draw_landmarks(
                    out, pose_res.pose_landmarks, self._mp_pose.POSE_CONNECTIONS,
                    landmark_drawing_spec=self._mp_draw.DrawingSpec(color=(124, 58, 237), thickness=2, circle_radius=3),
                    connection_drawing_spec=self._mp_draw.DrawingSpec(color=(167, 139, 250), thickness=2))
        else:
            res["pose_detected"] = False

        # ── Hands + fingers ──
        total = 0
        left_c = right_c = 0
        hands_data = []
        if hands_res.multi_hand_landmarks:
            res["hands_detected"] = True
            labels = []
            if hands_res.multi_handedness:
                labels = [h.classification[0].label for h in hands_res.multi_handedness]
            for i, hl in enumerate(hands_res.multi_hand_landmarks):
                label = labels[i] if i < len(labels) else "Right"
                c = self._count_fingers(hl, label)
                total += c
                if label == "Left":
                    left_c = c
                else:
                    right_c = c
                hands_data.append((hl, label))
                if draw:
                    self._mp_draw.draw_landmarks(
                        out, hl, self._mp_hands.HAND_CONNECTIONS,
                        self._mp_draw.DrawingSpec(color=(13, 148, 136), thickness=2, circle_radius=3),
                        self._mp_draw.DrawingSpec(color=(110, 231, 183), thickness=2))
            res["gesture"] = self._gesture(total, hands_data)

            # Clap detection: two hands close together quickly
            if len(hands_data) == 2:
                w1 = hands_data[0][0].landmark[0]
                w2 = hands_data[1][0].landmark[0]
                gap = abs(w1.x - w2.x) + abs(w1.y - w2.y)
                if gap < 0.12 and (time.time() - self._clap_t) > 0.6:
                    res["clap"] = True
                    self._clap_t = time.time()
        else:
            res["hands_detected"] = False
            res["gesture"] = "none"

        res["fingers"] = total
        res["fingers_left"] = left_c
        res["fingers_right"] = right_c

        # ── Face / emotion ──
        if face_res.multi_face_landmarks:
            res["face_detected"] = True
            emo, attn = self._analyze_emotion(face_res.multi_face_landmarks[0], w, h)
            res["emotion"] = emo
            res["attention"] = attn
        else:
            res["face_detected"] = False
            res["attention"] = 0.0

        self.last = res
        return out, res

    def close(self):
        for s in (self.pose, self.hands, self.face):
            try:
                if s:
                    s.close()
            except Exception:
                pass


if __name__ == "__main__":
    print("VisionEngine ready. OpenCV/MediaPipe available:", _HAS_CV)
