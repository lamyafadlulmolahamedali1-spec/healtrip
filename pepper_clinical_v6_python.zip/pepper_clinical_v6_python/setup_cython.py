"""
Cython build — compiles Pepper logic modules to .so/.pyd binaries
to protect source code. © 2026 Lamya F. H. Ali.

Usage:
    pip install cython
    python setup_cython.py build_ext --inplace

Compiles: vision_engine, task_generator, clinical, database, widgets.
The GUI entry (pepper_clinical_v6.py) can stay as .py or also be compiled.
After build, ship the .so/.pyd files + entry script (delete the .py sources
you wish to hide).
"""
from setuptools import setup
from Cython.Build import cythonize

MODULES = [
    "vision_engine.py",
    "task_generator.py",
    "clinical.py",
    "database.py",
    "widgets.py",
]

setup(
    name="PepperClinicalV6",
    ext_modules=cythonize(MODULES, compiler_directives={"language_level": "3"}),
    zip_safe=False,
)
