"""
╔══════════════════════════════════════════════════════════════════════╗
║   PEPPER CLINICAL INFINITY V6 — Local Database                      ║
║   © 2026 Lamya F. H. Ali — All Rights Reserved                       ║
║   SQLite store: children, sessions, task events, assessments.       ║
║   Powers the parent dashboard (overview / analytics / live).        ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import os
import json
import sqlite3
import secrets
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pepper_clinical.db")


def _conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL;")
    return c


def init_db():
    c = _conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS children(
        id TEXT PRIMARY KEY, name TEXT, age INTEGER, diagnosis TEXT,
        pin TEXT, created_at TEXT,
        skill_motor REAL DEFAULT 50, skill_cognitive REAL DEFAULT 50,
        skill_verbal REAL DEFAULT 50, skill_math REAL DEFAULT 50,
        skill_social REAL DEFAULT 50, skill_fine_motor REAL DEFAULT 50,
        total_sessions INTEGER DEFAULT 0, total_score INTEGER DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS sessions(
        id TEXT PRIMARY KEY, child_id TEXT, started_at TEXT, ended_at TEXT,
        duration_sec INTEGER DEFAULT 0, score INTEGER DEFAULT 0,
        tasks_total INTEGER DEFAULT 0, tasks_success INTEGER DEFAULT 0,
        tasks_fail INTEGER DEFAULT 0, tasks_mastered INTEGER DEFAULT 0,
        avg_attention REAL DEFAULT 0, dominant_emotion TEXT DEFAULT '',
        protocol TEXT DEFAULT 'ABA-DTT'
    );
    CREATE TABLE IF NOT EXISTS task_events(
        id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT, child_id TEXT,
        ts TEXT, domain TEXT, task_type TEXT, success INTEGER,
        attention REAL, emotion TEXT
    );
    CREATE TABLE IF NOT EXISTS assessments(
        id TEXT PRIMARY KEY, child_id TEXT, ts TEXT,
        total INTEGER, level TEXT, domain_scores TEXT, answers TEXT
    );
    """)
    c.commit()
    c.close()


def _uid():
    return secrets.token_hex(8)


def _now():
    return datetime.now().isoformat(timespec="seconds")


# ── Children ───────────────────────────────────────────────────────────
def add_child(name, age=6, diagnosis=""):
    c = _conn()
    cid = _uid()
    pin = "".join(secrets.choice("0123456789") for _ in range(6))
    c.execute("INSERT INTO children(id,name,age,diagnosis,pin,created_at) VALUES(?,?,?,?,?,?)",
              (cid, name, age, diagnosis, pin, _now()))
    c.commit()
    c.close()
    return cid, pin


def list_children():
    c = _conn()
    rows = c.execute("SELECT * FROM children ORDER BY created_at DESC").fetchall()
    c.close()
    return [dict(r) for r in rows]


def get_child(cid):
    c = _conn()
    r = c.execute("SELECT * FROM children WHERE id=?", (cid,)).fetchone()
    c.close()
    return dict(r) if r else None


def delete_child(cid):
    c = _conn()
    c.execute("DELETE FROM children WHERE id=?", (cid,))
    c.execute("DELETE FROM sessions WHERE child_id=?", (cid,))
    c.execute("DELETE FROM task_events WHERE child_id=?", (cid,))
    c.commit()
    c.close()


# ── Sessions ───────────────────────────────────────────────────────────
def start_session(child_id, protocol="ABA-DTT"):
    c = _conn()
    sid = _uid()
    c.execute("INSERT INTO sessions(id,child_id,started_at,protocol) VALUES(?,?,?,?)",
              (sid, child_id, _now(), protocol))
    c.commit()
    c.close()
    return sid


def log_task(session_id, child_id, domain, task_type, success, attention=0, emotion=""):
    c = _conn()
    c.execute("""INSERT INTO task_events(session_id,child_id,ts,domain,task_type,success,attention,emotion)
                 VALUES(?,?,?,?,?,?,?,?)""",
              (session_id, child_id, _now(), domain, task_type, 1 if success else 0, attention, emotion))
    c.commit()
    c.close()


def end_session(session_id, **stats):
    c = _conn()
    row = c.execute("SELECT child_id FROM sessions WHERE id=?", (session_id,)).fetchone()
    c.execute("""UPDATE sessions SET ended_at=?,duration_sec=?,score=?,tasks_total=?,
                 tasks_success=?,tasks_fail=?,tasks_mastered=?,avg_attention=?,dominant_emotion=?
                 WHERE id=?""",
              (_now(), stats.get("duration_sec", 0), stats.get("score", 0),
               stats.get("tasks_total", 0), stats.get("tasks_success", 0),
               stats.get("tasks_fail", 0), stats.get("tasks_mastered", 0),
               stats.get("avg_attention", 0), stats.get("dominant_emotion", ""), session_id))
    if row:
        cid = row["child_id"]
        c.execute("""UPDATE children SET total_sessions=total_sessions+1,
                     total_score=total_score+? WHERE id=?""",
                  (stats.get("score", 0), cid))
        # Adaptive skill update
        tt = stats.get("tasks_total", 0)
        if tt > 0:
            ratio = stats.get("tasks_success", 0) / tt
            bump = (ratio - 0.5) * 4
            ch = c.execute("SELECT * FROM children WHERE id=?", (cid,)).fetchone()
            for k in ("skill_motor", "skill_cognitive", "skill_verbal",
                      "skill_math", "skill_social", "skill_fine_motor"):
                nv = max(0, min(100, ch[k] + bump))
                c.execute(f"UPDATE children SET {k}=? WHERE id=?", (nv, cid))
    c.commit()
    c.close()


def session_history(child_id, limit=50):
    c = _conn()
    rows = c.execute("""SELECT * FROM sessions WHERE child_id=? AND ended_at IS NOT NULL
                        ORDER BY started_at DESC LIMIT ?""", (child_id, limit)).fetchall()
    c.close()
    return [dict(r) for r in rows]


def child_stats(child_id):
    c = _conn()
    ch = c.execute("SELECT * FROM children WHERE id=?", (child_id,)).fetchone()
    sessions = c.execute("""SELECT * FROM sessions WHERE child_id=? AND ended_at IS NOT NULL""",
                         (child_id,)).fetchall()
    events = c.execute("SELECT * FROM task_events WHERE child_id=?", (child_id,)).fetchall()
    c.close()
    if not ch:
        return None
    total_mastered = sum(s["tasks_mastered"] for s in sessions)
    attns = [s["avg_attention"] for s in sessions if s["avg_attention"]]
    avg_attn = round(sum(attns) / len(attns), 1) if attns else 0
    # domain success breakdown
    domain_stats = {}
    for e in events:
        d = e["domain"] or "Other"
        domain_stats.setdefault(d, {"total": 0, "success": 0})
        domain_stats[d]["total"] += 1
        domain_stats[d]["success"] += e["success"]
    return {
        "child": dict(ch),
        "total_sessions": ch["total_sessions"],
        "total_score": ch["total_score"],
        "total_mastered": total_mastered,
        "avg_attention": avg_attn,
        "skills": {
            "Motor": ch["skill_motor"], "Cognitive": ch["skill_cognitive"],
            "Verbal": ch["skill_verbal"], "Math": ch["skill_math"],
            "Social": ch["skill_social"], "Fine Motor": ch["skill_fine_motor"],
        },
        "domain_stats": domain_stats,
        "sessions": [dict(s) for s in sessions],
    }


# ── Assessments ────────────────────────────────────────────────────────
def save_assessment(child_id, result, answers):
    c = _conn()
    aid = _uid()
    c.execute("""INSERT INTO assessments(id,child_id,ts,total,level,domain_scores,answers)
                 VALUES(?,?,?,?,?,?,?)""",
              (aid, child_id, _now(), result["total"], result["level"],
               json.dumps(result["domain_scores"]), json.dumps(answers)))
    c.commit()
    c.close()
    return aid


def list_assessments(child_id):
    c = _conn()
    rows = c.execute("SELECT * FROM assessments WHERE child_id=? ORDER BY ts DESC", (child_id,)).fetchall()
    c.close()
    out = []
    for r in rows:
        d = dict(r)
        d["domain_scores"] = json.loads(d["domain_scores"] or "{}")
        out.append(d)
    return out


if __name__ == "__main__":
    if os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    init_db()
    cid, pin = add_child("Ahmed", 7, "ASD Level 1")
    print("child:", cid, "pin:", pin)
    sid = start_session(cid)
    for i in range(15):
        log_task(sid, cid, "Motor", "motor", i % 3 != 0, attention=70 + i, emotion="happy")
    end_session(sid, duration_sec=300, score=45, tasks_total=15, tasks_success=10,
                tasks_fail=5, tasks_mastered=1, avg_attention=78.5, dominant_emotion="happy")
    st = child_stats(cid)
    print("sessions:", st["total_sessions"], "| score:", st["total_score"],
          "| attn:", st["avg_attention"])
    print("domain_stats:", st["domain_stats"])
    print("✅ database works")
    os.remove(DB_PATH)
