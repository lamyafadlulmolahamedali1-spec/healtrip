"""
╔══════════════════════════════════════════════════════════════════════╗
║   PEPPER CLINICAL INFINITY V6 — Task Generator                      ║
║   © 2026 Lamya F. H. Ali — All Rights Reserved                       ║
║   100K+ adaptive tasks · ABA/DTT/TEACCH/ESDM/PRT/VB                  ║
║   NO feet tasks · NO jumping · includes DRAWING tasks               ║
╚══════════════════════════════════════════════════════════════════════╝
"""
import random

COLORS = [("red", "🔴", "#ef4444"), ("blue", "🔵", "#3b82f6"), ("green", "🟢", "#22c55e"),
          ("yellow", "🟡", "#eab308"), ("orange", "🟠", "#f97316"), ("purple", "🟣", "#a855f7"),
          ("pink", "🩷", "#ec4899"), ("brown", "🟤", "#92400e"), ("white", "⬜", "#e5e7eb"),
          ("black", "⬛", "#1e293b"), ("gray", "🩶", "#6b7280"), ("cyan", "🩵", "#06b6d4")]
ANIMALS = [("dog", "🐶"), ("cat", "🐱"), ("lion", "🦁"), ("elephant", "🐘"), ("rabbit", "🐰"),
           ("bear", "🐻"), ("horse", "🐴"), ("butterfly", "🦋"), ("penguin", "🐧"), ("owl", "🦉"),
           ("dolphin", "🐬"), ("fox", "🦊"), ("tiger", "🐯"), ("monkey", "🐒"), ("giraffe", "🦒"),
           ("turtle", "🐢"), ("frog", "🐸"), ("bee", "🐝"), ("fish", "🐟"), ("bird", "🐦")]
FRUITS = [("apple", "🍎"), ("banana", "🍌"), ("orange", "🍊"), ("grapes", "🍇"), ("strawberry", "🍓"),
          ("watermelon", "🍉"), ("mango", "🥭"), ("pineapple", "🍍"), ("kiwi", "🥝"), ("pear", "🍐"),
          ("lemon", "🍋"), ("cherry", "🍒"), ("peach", "🍑"), ("coconut", "🥥"), ("blueberry", "🫐")]
SHAPES = [("circle", "⭕"), ("square", "⬛"), ("triangle", "🔺"), ("star", "⭐"), ("heart", "❤️"),
          ("diamond", "🔷"), ("rectangle", "▬"), ("oval", "🥚"), ("moon", "🌙"), ("sun", "☀️")]
VEHICLES = [("car", "🚗"), ("bus", "🚌"), ("plane", "✈️"), ("train", "🚂"), ("boat", "⛵"),
            ("bike", "🚲"), ("helicopter", "🚁"), ("truck", "🚛"), ("rocket", "🚀")]
LETTERS = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
WORDS = ["cat", "dog", "sun", "ball", "fish", "tree", "star", "book", "milk", "play",
         "red", "blue", "one", "two", "happy", "yes", "more", "help", "mom", "dad"]
DRAW_ELEMENTS = [("line", "／", "Draw a straight line"), ("circle", "○", "Draw a circle"),
                 ("triangle", "△", "Draw a triangle"), ("square", "□", "Draw a square"),
                 ("heart", "♡", "Draw a heart"), ("star", "☆", "Draw a star"),
                 ("cross", "✚", "Draw a cross"), ("zigzag", "〰", "Draw a zigzag")]

# Motor tasks — NO feet, NO jumping
MOTORS = [
    ("clap", "👏", "CLAP your hands 3 times!", "clap", "Amazing clap!"),
    ("wave", "👋", "WAVE hello to the camera!", "wave", "Great wave!"),
    ("thumbs", "👍", "Show THUMBS UP!", "thumbs_up", "Thumbs up!"),
    ("nose", "👃", "Touch your NOSE!", "head_touch", "Found your nose!"),
    ("head", "🙆", "Touch the TOP of your HEAD!", "head_touch", "Head touch!"),
    ("arms", "🙌", "Raise BOTH ARMS up HIGH!", "hand_raised", "Arms up!"),
    ("smile", "😄", "Show your BIGGEST SMILE!", "smile", "Beautiful smile!"),
    ("point", "☝️", "POINT at the camera!", "point", "Great pointing!"),
    ("peace", "✌️", "Show a PEACE sign!", "peace", "Peace!"),
    ("fist", "✊", "Make a FIST!", "fist", "Strong fist!"),
    ("openhand", "🖐️", "Show an OPEN hand!", "open_palm", "Open hand!"),
]

SOCIAL = [
    ("please", "🙏", "Say PLEASE when you want something!"),
    ("thank you", "💙", "Say THANK YOU!"),
    ("hello", "👋", "Say HELLO and wave!"),
    ("help", "🆘", "Ask for HELP: 'Help please!'"),
    ("sorry", "💛", "Say SORRY nicely!"),
    ("good job", "⭐", "Say GOOD JOB!"),
    ("my turn", "🔄", "Say 'MY TURN' politely!"),
    ("high five", "✋", "Give a HIGH FIVE!"),
]

DAILY = [
    ("wash hands", "🧼", "Show how you WASH your hands!", "washing hands for kids tutorial"),
    ("brush teeth", "🦷", "Show how you BRUSH your teeth!", "brushing teeth song for kids"),
    ("comb hair", "💇", "Show how you COMB your hair!", "combing hair for kids"),
    ("eat with spoon", "🥄", "Pretend to EAT with a spoon!", "using spoon for kids"),
    ("drink water", "🥤", "Pretend to DRINK from a cup!", "drinking from cup toddler"),
    ("get dressed", "👕", "Pretend to put on a SHIRT!", "getting dressed song kids"),
    ("tie shoes", "👟", "Pretend to TIE your shoes!", "tying shoes for kids"),
    ("clean up", "🧹", "Show how you CLEAN UP toys!", "clean up song for kids"),
]


def _grid(pool, label, em, n, domain, protocol):
    tgt = (label, em)
    others = random.sample([x for x in pool if x[0] != label], min(n - 1, len(pool) - 1))
    opts = others + [tgt]
    random.shuffle(opts)
    return {
        "type": "grid", "name": f"Find {label}", "em": em,
        "instruction": f"Tap the {label}! {em}",
        "options": [{"label": o[0], "em": o[1],
                     "color": next((c[2] for c in COLORS if c[0] == o[0]), "#ede9fe")} for o in opts],
        "correct": opts.index(tgt), "domain": domain, "protocol": protocol,
        "tokens": 3, "success": f"Yes! {label}! {em}", "fail": f"Find the {label}! {em}",
    }


class TaskGenerator:
    DOMAINS = ["motor", "cognitive", "verbal", "math", "social", "daily", "drawing"]

    @staticmethod
    def generate(domain=None, level=1, count=20):
        out = []
        for _ in range(count):
            d = domain or random.choice(TaskGenerator.DOMAINS)
            out.append(TaskGenerator._build(d, level))
        return out

    @staticmethod
    def _build(domain, level=1):
        fn = {
            "motor": TaskGenerator._motor, "cognitive": TaskGenerator._cognitive,
            "verbal": TaskGenerator._verbal, "math": TaskGenerator._math,
            "social": TaskGenerator._social, "daily": TaskGenerator._daily,
            "drawing": TaskGenerator._drawing,
        }.get(domain, TaskGenerator._motor)
        return fn(level)

    @staticmethod
    def _motor(lv=1):
        m = random.choice(MOTORS)
        return {"type": "motor", "name": m[0].title(), "em": m[1], "instruction": m[2],
                "verify": m[3], "domain": "Motor", "protocol": random.choice(["ABA-DTT", "ESDM", "PRT"]),
                "tokens": 3, "success": m[4], "fail": f"Try again! {m[1]}"}

    @staticmethod
    def _cognitive(lv=1):
        pick = random.choice(["color", "animal", "fruit", "shape", "vehicle"])
        pool = {"color": COLORS, "animal": ANIMALS, "fruit": FRUITS,
                "shape": SHAPES, "vehicle": VEHICLES}[pick]
        tgt = random.choice(pool)
        return _grid(pool, tgt[0], tgt[1], min(3 + lv, len(pool)), "Cognitive",
                     random.choice(["TEACCH", "ABA-DTT"]))

    @staticmethod
    def _verbal(lv=1):
        w = random.choice(WORDS)
        return {"type": "word", "name": f"Say: {w}", "em": "🗣️",
                "instruction": f"Say the word: {w.upper()}!", "word": w,
                "domain": "Verbal", "protocol": random.choice(["ESDM", "Verbal-Behavior"]),
                "tokens": 4, "success": f"I heard {w.upper()}!", "fail": f"Say: {w}!"}

    @staticmethod
    def _math(lv=1):
        if lv == 1:
            n = random.randint(1, 5)
            return {"type": "number", "name": f"Show {n}", "em": "🖐️",
                    "instruction": f"Show me {n} finger{'s' if n > 1 else ''}!",
                    "target": n, "domain": "Math", "protocol": "ABA-DTT",
                    "tokens": 4, "success": f"Yes! {n} fingers!", "fail": f"Show {n} fingers!"}
        else:
            a, b = random.randint(1, 5), random.randint(0, 4)
            s = a + b
            opts = list({s, s + 1, max(0, s - 1), s + 2})[:4]
            while len(opts) < 4:
                opts.append(s + len(opts))
            random.shuffle(opts)
            return {"type": "grid", "name": f"{a}+{b}", "em": "🔢",
                    "instruction": f"What is {a} + {b}?",
                    "options": [{"label": str(o), "em": str(o), "color": "#ede9fe"} for o in opts],
                    "correct": opts.index(s), "domain": "Math", "protocol": "ABA-DTT",
                    "tokens": 5, "success": f"Correct! {a}+{b}={s}!", "fail": f"It's {s}!"}

    @staticmethod
    def _social(lv=1):
        t = random.choice(SOCIAL)
        return {"type": "social", "name": t[0].title(), "em": t[1], "instruction": t[2],
                "phrase": t[0], "domain": "Social", "protocol": random.choice(["ESDM", "PRT"]),
                "tokens": 4, "success": f"Excellent! {t[1]}", "fail": f"Try: {t[0]}! {t[1]}"}

    @staticmethod
    def _daily(lv=1):
        t = random.choice(DAILY)
        return {"type": "daily", "name": t[0].title(), "em": t[1], "instruction": t[2],
                "youtube_query": t[3], "domain": "Daily Living", "protocol": "TEACCH",
                "tokens": 4, "success": "Amazing life skill!", "fail": "Try again!"}

    @staticmethod
    def _drawing(lv=1):
        # Choose letter, word, or element
        kind = random.choice(["letter", "element", "shape"])
        if kind == "letter":
            ch = random.choice(LETTERS)
            return {"type": "drawing", "name": f"Draw {ch}", "em": "✏️",
                    "instruction": f"Trace the letter {ch} on the board!",
                    "draw_target": ch, "draw_kind": "letter",
                    "domain": "Fine Motor", "protocol": "TEACCH",
                    "tokens": 5, "success": f"Beautiful {ch}!", "fail": "Trace over the light lines!"}
        elif kind == "shape":
            sh = random.choice(SHAPES)
            return {"type": "drawing", "name": f"Draw {sh[0]}", "em": "✏️",
                    "instruction": f"Trace the {sh[0]} on the board! {sh[1]}",
                    "draw_target": sh[0], "draw_kind": "shape",
                    "domain": "Fine Motor", "protocol": "TEACCH",
                    "tokens": 5, "success": f"Great {sh[0]}!", "fail": "Trace over the light lines!"}
        else:
            el = random.choice(DRAW_ELEMENTS)
            return {"type": "drawing", "name": el[2], "em": "✏️",
                    "instruction": f"{el[2]} on the board! {el[1]}",
                    "draw_target": el[0], "draw_kind": "element",
                    "domain": "Fine Motor", "protocol": "TEACCH",
                    "tokens": 5, "success": f"Perfect {el[0]}!", "fail": "Trace over the light lines!"}


if __name__ == "__main__":
    g = TaskGenerator()
    for d in TaskGenerator.DOMAINS:
        t = g.generate(domain=d, count=1)[0]
        print(f"{d:10} -> {t['type']:8} | {t['instruction']}")
    print("\nNo feet/jumping check:",
          all("feet" not in str(m).lower() and "jump" not in str(m).lower() for m in MOTORS))
