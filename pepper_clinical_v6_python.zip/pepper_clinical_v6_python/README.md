# Pepper Clinical Infinity V6 — Python Desktop App
© 2026 Lamya F. H. Ali — All Rights Reserved

AI-powered autism therapy platform. Backend + frontend in Python (PyQt6).

## Files
| File | Purpose |
|------|---------|
| `pepper_clinical_v6.py` | **Main app** — run this. GUI + all screens. |
| `vision_engine.py` | High-performance MediaPipe AI: skeleton, posture, joints, emotion, finger counting. OpenCV fallback if MediaPipe-solutions missing. |
| `task_generator.py` | 100K+ adaptive tasks (ABA/DTT/TEACCH/ESDM/PRT/VB). **No feet, no jumping.** Includes drawing tasks. |
| `clinical.py` | ISAA assessment (40 items) + AI Advisor "Dr. Pepper" with full memory map. |
| `database.py` | SQLite store — powers parent dashboard. |
| `widgets.py` | Camera thread, Drawing board (trace detection), Celebration overlay. |
| `setup_cython.py` | Compile logic modules to binaries for IP protection. |

## Install & Run
```bash
pip install -r requirements.txt
python pepper_clinical_v6.py
```

## What's Fixed / New in this build
- **Camera opens via START button** — high-performance MediaPipe (skeleton, posture, joints, emotion, fingers). Auto-verifies number & motor tasks live.
- **No feet tasks, no jumping.**
- **Drawing board** — trace letters / shapes / elements over a light guide; coverage detected → check given.
- **Celebration every 10 tasks** — falling stars + crown 👑 + clap prompt.
- **Working buttons:** YouTube video + YouTube search (daily-life tasks), Calm Music, Games, PDF report.
- **Voice recorder** — press to start / press to stop (needs `sounddevice`).
- **Parent Dashboard fully functional:**
  - **Overview** — live stat cards + skill progress bars (no longer frozen at zero).
  - **Analytics** — score line chart, success-by-domain bar chart, skill bars (pure-Qt charts, no external deps).
  - **Live** — real-time emotion / attention / fingers / gesture during a session.
  - **ISAA Assess** — full Indian Scale for Assessment of Autism (40 items, 6 domains, scored & classified).
  - **AI Advisor** — Dr. Pepper answers and **remembers every question** (topic memory map).

## Code Protection (Cython)
```bash
pip install cython
python setup_cython.py build_ext --inplace
# ship the resulting .so/.pyd + pepper_clinical_v6.py; remove .py sources to hide them
```

## Server / Distribution
- This is the desktop client. For the secure server backend (FastAPI, JWT, encryption) see the separate `pepper_server_v6` package.
- Package as a standalone executable with PyInstaller:
  ```bash
  pip install pyinstaller
  pyinstaller --onefile --windowed pepper_clinical_v6.py
  ```

All copyrights © 2026 Lamya F. H. Ali.
